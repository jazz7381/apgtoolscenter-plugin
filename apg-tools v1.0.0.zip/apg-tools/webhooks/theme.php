<?php

require_once('../includes/config.php');
define('APGPATH', ABSPATH.'wp-content/plugins/apg-tools');

require_once(ABSPATH.'wp-admin/includes/admin.php');
require_once(ABSPATH.'wp-admin/includes/file.php');
require_once(ABSPATH.'wp-admin/includes/plugin.php');
require_once(ABSPATH.'wp-includes/theme.php');
require_once(ABSPATH.'wp-content/plugins/apg-tools/includes/helper.php');

switch_theme('twentytwenty');